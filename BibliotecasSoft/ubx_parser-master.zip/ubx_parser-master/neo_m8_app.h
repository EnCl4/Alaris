/*
 * neo_m8_app.h
 *
 *  Created on: Jul 17, 2018
 *      Author: alexis
 */

#ifndef NEO_M8_APP_H_
#define NEO_M8_APP_H_

void GPSTask(void const * argument);

#endif /* NEO_M8_APP_H_ */
